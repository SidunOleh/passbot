<?php

namespace App\Http\Controllers\Tg;

use App\Http\Controllers\Controller;
use App\Models\Site;
use Illuminate\Http\Request;
use TelegramBot\Api\Client as TgClient;

class PassBotController extends Controller
{
    private $passbot;
    
    public function __construct()
    {
        $this->passbot = new TgClient(config('tg.passbot.token'));
    }
    
    public function __invoke()
    {
        $this->passbot->command('start', function ($message) {
            $this->passbot->sendMessage($message->getChat()->getId(), view('tg.commands')->render());
        });
        
        $this->passbot->command('help', function ($message) {
            $this->passbot->sendMessage($message->getChat()->getId(), view('tg.commands')->render());
        });

        $this->passbot->command('sites', function ($message) {
            $commandStr = $message->getText();
            $commandArgs = $this->getCommandArgs($commandStr);
            
            if (! $commandArgs or is_numeric($commandArgs[0])) {
                $response = $this->getSites($commandArgs[0] ?? 1);
            } else {
                $response = $this->getCredentials($commandArgs[0]);    
            }

            $this->passbot->sendMessage($message->getChat()->getId(), $response, '', true);
        });

        $this->passbot->run();
    }
    
    private function getCommandArgs($commandStr)
    {
        $commandArr = array_filter(explode(' ', $commandStr), fn($v) => $v);
        
        unset($commandArr[0]);
        $commandArgs = array_values($commandArr);
        
        return $commandArgs;
    }
    
    private function getSites($page=1)
    {
        $offset = (abs($page) - 1) * 10;
        $sites = Site::offset($offset)
            ->limit(10)
            ->orderByDesc('created_at')
            ->get();
            
        return view('tg.sites', ['sites' => $sites,])
            ->render();
    }
    
    private function getCredentials($site)
    {
        $credentials = Site::firstWhere('name', 'like', "{$site}%")
            ->credentials()
            ->orderByDesc('created_at')
            ->get() ?? [];
            
        return view('tg.credentials', ['credentials' => $credentials,])
            ->render();
    }
}
