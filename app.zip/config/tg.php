<?php

return [
    'passbot' => [
        'token' => '6043059659:AAH5juQyosOVq8VmKQVObdhln7gC38aknWA',
    ],
];