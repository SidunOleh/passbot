/sites - list of sites

=================================================

/sites <name of site> - site credentials

=================================================