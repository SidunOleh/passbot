<?php if(count($credentials)): ?>
<?php $__currentLoopData = $credentials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credential): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($credential->name); ?>


<?php $__currentLoopData = $credential->credentials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo $item; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

=================================================

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
Not Found
<?php endif; ?><?php /**PATH /home/bazardot/passbot.jokeit.io/resources/views/tg/credentials.blade.php ENDPATH**/ ?>