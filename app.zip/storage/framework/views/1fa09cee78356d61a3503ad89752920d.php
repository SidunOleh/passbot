<?php if(count($sites)): ?>
<?php $__currentLoopData = $sites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $site): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($site->name); ?>


<?php echo e($site->url); ?>


=================================================

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
Not Found
<?php endif; ?><?php /**PATH /home/bazardot/passbot.jokeit.io/resources/views/tg/sites.blade.php ENDPATH**/ ?>