/sites - list of sites

=================================================

/sites <name of site> - site credentials

=================================================<?php /**PATH /home/bazardot/passbot.jokeit.io/resources/views/tg/commands.blade.php ENDPATH**/ ?>